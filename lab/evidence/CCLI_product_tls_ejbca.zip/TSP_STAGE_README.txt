﻿# CCLI TSP TLS stage (Annex / EJBCA lab)

Copied from `C:\Yahia\projects\CCLI\apps\ccli\config\tls\ejbca` on 2026-10-06 13:00.

## Wire in Test Suite Pro (other PC OK â€” copy this folder)

| Role | Files |
|------|-------|
| Trust anchor | root_CA.pem |
| Transport TLS (Cert A) | client_tls.pem + client_tsp.key |
| MMS Security (Cert B) | client.pem + client_tsp.key |
| Viewer / RBAC negative | viewer.pem + viewer.key |
| CRL negative (P3-09) | revoked.* + lab_crl.pem |

Connection: 192.168.10.1 port **3782** TLS â€” not cleartext 102.

See: lab/EJBCA_LAB_SETUP.md section 9â€“10
