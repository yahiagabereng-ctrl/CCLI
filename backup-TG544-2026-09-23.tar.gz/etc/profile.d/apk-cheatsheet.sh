if [ -x /usr/bin/apk ] ; then
cat << EOF

EOF
fi
